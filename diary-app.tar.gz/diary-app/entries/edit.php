<?php
require '../config.php';
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $conn->prepare("UPDATE entries SET title=?, content=? WHERE id=?");
    $stmt->bind_param("ssi", $title, $content, $id);
    $stmt->execute();
    header("Location: ../index.php");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM entries WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Entry</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<h2>Edit Entry</h2>
<form method="post">
    Title: <input type="text" name="title" value="<?php echo htmlspecialchars($row['title']); ?>"><br>
    Content:<br>
    <textarea name="content" rows="5" cols="40"><?php echo htmlspecialchars($row['content']); ?></textarea><br>
    <input type="submit" value="Update">
    <input type="button" value="Return" onclick="location.href='../index.php'">
</form>
</body>
</html>