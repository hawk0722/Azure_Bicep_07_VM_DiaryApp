<?php
require 'config.php';
$result = $conn->query("SELECT * FROM entries ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Diary</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include 'templates/header.php'; ?>
<main>
<table style="width: auto; margin: 0 auto;">
    <thead>
        <tr>
            <th colspan="2">Diary Entries</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td colspan="2"><a href="entries/create.php">Create New Entry</a></td>
        </tr>
    </tbody>
</table>
<div class="table-wrapper">
<table>
    <thead>
        <tr>
            <th>Title</th>
            <th>Content</th>
            <th>Created at</th>
            <th>Edit / Delete</th>
        </tr>
    </thead>
    <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td class="content-cell"><?php echo nl2br(htmlspecialchars($row['content'])); ?></td>
            <td><?php echo htmlspecialchars($row['created_at']); ?></td>
            <td>
                <a href="entries/edit.php?id=<?php echo $row['id']; ?>">Edit</a> |
                <a href="entries/delete.php?id=<?php echo $row['id']; ?>">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
</div>
</main>
<?php include 'templates/footer.php'; ?>
</body>
</html>