<?php
$host = 'localhost';
$user = 'root';
$password = '<your_password_here>';
$dbname = 'diary';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
?>